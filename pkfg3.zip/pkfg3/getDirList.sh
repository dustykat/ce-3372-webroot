#!/bin/bash
# bash script to generate a file with list of directories with name structure
# ******0d assumed to be content directories
# list contents of this directory -- redirect to dir.list.txt
ls > dir.list.txt
# filter dir.list.txt using grep look for the literal '0d' to find the list of directories.
grep '0d' dir.list.txt > dir2.list.txt
# clean up the directory
rm dir.list.txt
mv dir2.list.txt dir.list.txt
echo "dir.list.txt is list of station directories"
echo "now run python script to check file time stamps"
echo "locate script source"
echo "running Python 2.7"
python ../scripts/cleveland/mkCmdScript.py
echo "python script completed"
echo "ReCheckPKFQ.txt is list of file check(s) status"
