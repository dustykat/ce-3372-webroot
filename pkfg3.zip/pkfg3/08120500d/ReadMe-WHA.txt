accept
# downward trend and direction consistent with much of the greater region, I think we can just barely live with use of the period of record. Did consider raising LOT to 1000 cfs but decided against

