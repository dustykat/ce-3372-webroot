Revision Complete

Notes:
LO RAISED TO 1100CFS
