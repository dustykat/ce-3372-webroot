Completed 27FEB2019

Notes: 