Completed 30Jan2019

Notes: Unsure if anything needs to be changed; PeakFQ output resulted in off results.