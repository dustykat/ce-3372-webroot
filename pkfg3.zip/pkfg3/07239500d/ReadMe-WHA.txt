accept
# start analysis in 1938, ignore the earliest records as they appear oddly distribute. Go ahead and permit the code 6s.
