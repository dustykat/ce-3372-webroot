accept
# use historical record in the peak values file, 1909-1936  3870-Inf. Visually, WHA is not too comfortable with using the largest peak as a measure of general skew. A trimmed L-moments computation could be interesting to compare.
