accept
# revise LOT to 60 cfs
