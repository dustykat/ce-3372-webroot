reject
# systematic trend in the record but appears also a change point. Note enough earlier record to use
