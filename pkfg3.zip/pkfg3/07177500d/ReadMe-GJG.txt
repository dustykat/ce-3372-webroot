Completed 30Jan2019

Notes:End year changed from 2017 to 1984 because of indicator shifts from standard to "5".