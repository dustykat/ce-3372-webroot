accept
# no PRT file, ignore the record gap
