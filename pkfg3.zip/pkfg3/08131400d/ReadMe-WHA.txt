accept
# historical peak looks to be assigned too big a historical length, but not much more to go on
