accept
# do not do any gap infill for this station
