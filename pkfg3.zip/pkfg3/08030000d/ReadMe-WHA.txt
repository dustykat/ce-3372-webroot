accept
# raise LOT to 800 cfs
