Completed 24Jan2019

Notes: 