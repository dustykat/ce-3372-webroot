Completed 20 MARCH 2019

Notes: Perceptible range lo assigned to 1985, 1990, 1995, 1997-1998.