accept
# raise LOT to 650 cfs and re-evaluate
