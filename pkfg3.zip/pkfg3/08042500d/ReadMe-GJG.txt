Completed 20FEB2019

Notes: OBSERVED MAX ASSIGNED TO GAP FOR 1954. End year changed to 1984 because of missing data 1985+. 