accept
# we can just live with the downward trend starting before the code 6s kick in
