accept
# stop analysis in 1994 because of seemingly a change point, but permit the code 6s upto that point. It is possible that PeakFQ has a bug. If the urban/reg are allowed into the record, it does not appear to honor then the use of 1994 as an ending date
