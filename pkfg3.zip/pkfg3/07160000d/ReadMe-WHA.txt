accept
# change LOT to 10,000 cfs. perception thresholds not set correctly.
