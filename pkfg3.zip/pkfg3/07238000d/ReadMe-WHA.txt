reject
# systematic trend from the very beginning, reject
