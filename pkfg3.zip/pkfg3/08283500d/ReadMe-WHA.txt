accept
# do not using any infill, all gaps in record need to be Inf-Inf
