accept
# Possibly it would be okay to only analyze modern record starting in the mid 1980s. But it is a hard call.
