accept
# need the PeakFQ input graphic
