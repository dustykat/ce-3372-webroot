Completed 21FEB2019

Notes: