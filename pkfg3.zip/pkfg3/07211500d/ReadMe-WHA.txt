reject
# analysis set up okay, but large systematic trend means this stations needs to be rejected. The master list mechanism will show this in pkfg3_gage_list_rejected.txt
