accept
# do not use any gap infill for this station, downward trend in the data but the LOT just seems enough to truncate the record to treat as acceptable. Given another 20 years of data in the future or so, a later analyst might decide to reject this station or work on just the more "modern" record.
