accept
# do not using any infill, all gaps in record need to be Inf-Inf. The gap is just a bit big relative to how much bigger the peak of the record is.
