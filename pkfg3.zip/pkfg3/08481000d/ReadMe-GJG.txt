Completed 20 MARCH 2019

Notes:Perceptible range lo assigned to 1978-2000, 2009.

End year changed to 2013 to asjust for missing data.