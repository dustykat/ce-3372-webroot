Completed 30Jan2019

Notes: marker "C" -> Urban; dont use