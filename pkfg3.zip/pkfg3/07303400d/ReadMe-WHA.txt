accept
# incorrect perception thresholds used [reversed], use the POR for the gap. rise LOT to 1000 cfs
