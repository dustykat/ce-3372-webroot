Revision Complete

Notes:
LO ASSIGNED TO 2,000

