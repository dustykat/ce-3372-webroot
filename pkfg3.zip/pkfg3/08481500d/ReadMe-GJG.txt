Completed 20 MARCH 2019

Notes:inf perceptible range assigned to 1997-2001. 
