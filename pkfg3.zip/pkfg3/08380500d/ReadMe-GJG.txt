Completed 19 MARCH 2019

Notes: Perceptible range lo assigned to 1923-1924.