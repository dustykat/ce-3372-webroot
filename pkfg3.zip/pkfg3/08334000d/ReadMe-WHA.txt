accept
# seems reasonable choice on the one isolated gap in record. NM gages have a lot of these one year drops compared to TX and even OK.
