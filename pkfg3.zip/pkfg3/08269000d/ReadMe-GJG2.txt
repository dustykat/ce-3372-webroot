Revision Complete

Notes:
LO ASSIGNED TO 30cfs.
