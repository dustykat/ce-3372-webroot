Completed 20 MARCH 2019

Notes:Perceptible range lo assigned to 19985-1987, 1989-1990.