accept
# ignore the first two years of record. Only use record from 1949 and on.
