accept
# use only the non Code6 record because this is a skew study. The upper tail appears still active at this site, but for these analyses, we want a rural-like generalized skew.
