accept
# raise LOT to about 9000 cfs to make a top tail fitting problem, the historical record mentioned in the peak file is just gage height and does not seem too useful.
