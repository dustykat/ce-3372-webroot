accept
# low end inflation towards smaller values, but the LOT appears to truncate these away in an acceptable manner
