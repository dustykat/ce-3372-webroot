accept
# can use the historical gage height to set a perception threshold
