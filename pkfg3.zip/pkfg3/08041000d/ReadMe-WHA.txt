accept
# can use the rich historical record as perception thresholds, do not use the code 6s
