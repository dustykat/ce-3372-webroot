accept
# another case of one code 6 leaking into the record but then not used. Perhaps this is just what PeakFQ does and we should live with it. Need to investigate. Stop analysis after 1991.
