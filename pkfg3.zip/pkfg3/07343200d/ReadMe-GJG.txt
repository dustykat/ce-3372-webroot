Completed 30Jan2019

Notes: End year changed from 2017 to 1992 because of change in indicator from standart to "6".