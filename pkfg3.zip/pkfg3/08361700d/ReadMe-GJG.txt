Completed 08 MARCH 2019
, 
Notes: Perceptible Threshold lo assigned to 1996-1998, 2000.