accept
# go ahead and use the perception threshold to plug a few gaps, peak seems large enough, the code Cs (urban peaks) are in error and need to be allowed into the analyses.
