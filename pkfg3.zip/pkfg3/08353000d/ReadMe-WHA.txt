reject
# substantial and systematic trend, possibly one could normalize out the trend and study the asymmetry at that point but beyond our study.

