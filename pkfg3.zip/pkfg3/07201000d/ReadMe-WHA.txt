accept
# No PRT file, but revise and do not do any gap infill for this station, permit the urban peaks in. These appear as errors in the USGS data base.
