accept
# do not include the 1912 peak, start analysis in 1934.
