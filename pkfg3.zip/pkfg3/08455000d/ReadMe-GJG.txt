Completed 30Jan2019

Notes: 