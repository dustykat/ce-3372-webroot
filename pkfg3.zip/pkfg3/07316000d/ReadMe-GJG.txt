Completed 30Jan2019

Notes: Start year changed from 1936 to 1943 because of change in indicator from standard to "5".