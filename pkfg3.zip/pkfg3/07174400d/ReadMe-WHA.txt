accept
# revise LOT to 2,000 cfs
