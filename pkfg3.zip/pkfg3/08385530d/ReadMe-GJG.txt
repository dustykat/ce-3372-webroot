Completed 19 MARCH 2019

Notes:Perceptible threshold lo assigned for 1966, 1985, 1997-2001, 2003, 2016.