accept
# Revise the perception thresholds. [85000, inf] 1912-1925
# Review the perception thresholds. [100000, inf] 1939
