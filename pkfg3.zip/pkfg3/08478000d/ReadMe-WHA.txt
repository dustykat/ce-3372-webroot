accept
#  September 2013 major flood event in south NM is well known, perception threshold for the gaps is reasonable.
