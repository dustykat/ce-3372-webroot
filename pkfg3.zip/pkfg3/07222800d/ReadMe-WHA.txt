accept
# seems good enough to infill with the max of the period of record with the historical peak sitting in the middle of a short gap. Suggests some type of general awareness of events on this watershed. 
