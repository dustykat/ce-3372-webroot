accept
# do not use gap infill for this station, accept the urban peaks into the analysis as these appear in error within the USGS database.
