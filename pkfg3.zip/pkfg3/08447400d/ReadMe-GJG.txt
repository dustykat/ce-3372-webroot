Completed 30Jan2019

Notes: Changed end year from 1966 to 1954 because of shift in point indicator from "5" to "6".