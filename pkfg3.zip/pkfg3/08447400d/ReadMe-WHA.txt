accept
# permit the code 6s into the analysis

