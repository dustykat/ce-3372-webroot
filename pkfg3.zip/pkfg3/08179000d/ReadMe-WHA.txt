accept
# 1978 peak used properly in the gap infill
