accept
# The biggest peaks just do not seem large enough to quite justify the gap infill. Set the missing record to -Inf to +Inf.
