accept
# perception thresholds reverse, but agree will use of POR peak. Hold the LOT at 8450 cfs (check its output after the perception thresholds are changed).
