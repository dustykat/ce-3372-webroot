reject
# Systematic trend in the data. Highly nonstationary.
