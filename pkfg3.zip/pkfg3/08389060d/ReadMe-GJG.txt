Completed 19 MARCH 2019

Notes:Perceptible threshold lo assigned to 1970, 1978, 1985-1988, 1992.