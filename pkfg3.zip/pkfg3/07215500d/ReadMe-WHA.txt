accept
# do not use gap infill, stop analysis in 1966. Severe downward trend appears to start these with variance inflation but declining peaks.
