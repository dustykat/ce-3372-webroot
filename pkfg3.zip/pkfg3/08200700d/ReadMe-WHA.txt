accept
# perception thresholds should be 1920-1960: 63600 -- Inf and 63600 is 1997 and 2000 peaks, gage height judgment, raise LOT to 6000 cfs for improved upper tail
