accept
# 1967 and 1971 should plot above the line because we know them to be large and historical, so do not consider revision via a LOT change
