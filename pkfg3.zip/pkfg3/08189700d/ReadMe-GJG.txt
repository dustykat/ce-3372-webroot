Completed 26FEB2019

Notes: 