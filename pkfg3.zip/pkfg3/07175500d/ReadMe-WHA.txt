accept
# do not use the historical peak, do not gap fill---use -Inf to +Inf for the missing record years. Peak of POR is in the regulated area. Go ahead and use the regulated peaks. Set LOT to 7,000 cfs
