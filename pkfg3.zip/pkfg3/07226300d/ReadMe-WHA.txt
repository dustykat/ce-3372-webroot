accept
# set LOT to 300 cfs, do not gap infill, the urban peaks need to be permitted because surely Roy, NM is not urbanized enough, suspect erroneous information in the peak-values file
