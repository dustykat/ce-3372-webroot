# The script getDirList.sh is a bash shell script that examines the entire directory
# and creates a list of subdirectories to be examined.
# 
# This list is named dir.list.txt
#
# The script then executes a python script that is stored in the scripts section of the repository
# ../scripts/theodore/mkCmdScript.py
#
# This script reads the file dir.list.txt and searches each directory in the list for
# the existance of files named site_id.PNG and site_id_inp.PNG
# 
# If the file(s) exist, then the script accesses their mtime (linux modify time stamp)
# and converts the HH:MM:SS portion of the time stamp into seconds.
# The time stamps (of both files exist) and differenced, and if the absolute value of the difference is
# greater than sixty seconds, the program generates a message (to that effect) and stores that result
# in a file named ReCheckPKFQ.txt
#
# The run time of the script is reported in the output file.  
#
# usage of the script is as follows
#
# 
#
# at the shell prompt type: ./getDirList.sh
#
# The scripts should be safe even if the process fails.
#
# The python script is written using python 2.7 syntax, changes for python 3 may be necessary,
# those changes would be in the print() and file.write() portions.
#
# Theodore G. Cleveland
# 27 July 2019



