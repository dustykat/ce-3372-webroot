accept
# would be okay to gap infill if the code 6s were permitted. The note by Grant seems to indicate that he thinks the gap needs to be filled, which is probably correct via the PeakFQ interface seeing the missing year, but the code 6s are loaded and the PRT file makes this clear. Revise to use only the nonCode 6 record and do not gap fill.
