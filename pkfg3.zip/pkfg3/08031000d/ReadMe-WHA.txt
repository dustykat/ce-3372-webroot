accept
# erroneous 1940? gage height 14.85? Use Harvey for all gaps
