Completed 20FEB2019

Notes: 