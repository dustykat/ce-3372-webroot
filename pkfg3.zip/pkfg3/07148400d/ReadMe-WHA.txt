reject
# systematic trend with three visible change points

