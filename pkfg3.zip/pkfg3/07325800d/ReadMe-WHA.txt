accept
# perception thresholds reverse, but go ahead an use peak POR for the short gap
