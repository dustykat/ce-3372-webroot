Completed 24Jan2019

Notes: Start year changed to 1946 becuase of missing record in years 1943-1945.