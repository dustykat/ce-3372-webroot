accept
# difficult. The historical peaks do not seem that exotic, the high LOT is used in an effort to mitigate for the downward trend in the low end but allowing for the code 6 inclusion
