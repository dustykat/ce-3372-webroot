RX <- read.table("pkfg3_redundant_gage.txt", header=TRUE, colClasses="character")
tmp <- unlist(strsplit(RX$site_no, ":"))
sitesA <- tmp[seq(1,length(tmp)-1,by=2)]
sitesB <- tmp[seq(2,length(tmp)-0,by=2)]
sitesK <- sapply(RX$keep_site, function(k) { tmp <- unlist(strsplit(k[[1]], "_")); tmp[1] })
names(sitesK) <- NULL


sitesAB <- data.frame(site_no=unique(c(sitesA, sitesB)), stringsAsFactors=FALSE)
sitesK <- data.frame(site_no=unique(sitesK), stringsAsFactors=FALSE)
length(sitesAB$site_no)
length(sitesK$site_no)

sites <- rbind(sitesAB, sitesK)
length(sites$site_no)

h <- aggregate(sites, by=list(sites$site_no), length)
rejects <- h$Group.1[h$site_no == 1];

manual_rejects <- c("08070200", "08111700", "08155200", "08155300", "08165500", "08171300",
                    "08178880", "08206600", "08271000", "08284100", "")
manual_reinstates <- c("08283500")

rejects <- c(rejects, manual_rejects)
rejects <- sort(unique(rejects))
for(site in manual_reinstates) {
  rejects <- rejects[rejects != site]
}

write.table(data.frame(site_no=rejects, stringsAsFactors=FALSE),
            file="pkfg3_reject_by_redundancy.txt", row.names=FALSE, quote=FALSE)
