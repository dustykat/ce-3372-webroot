accept
# judging from gage height at 1982 peak, can not use the 1960 historical gage height is lower but we do not have the peak itself
