accept
# revise historical record, incorrect peak used for the perception threshold. Could be debate on how to interpret the time window for 1919 historical peak, but use the 1967 instead. 1920-1961 105000:Inf; 1978-2000 105000:Inf  The 1919 becomes 25500:Inf. Gages looks like it has a tropical cyclone upper tail.
