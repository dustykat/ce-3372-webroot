Completed 24Jan2019

Notes: Changed start year to 1940 because of missing record between years 1935-1939. Changed end year to 1985 because of change in point  markers from standard to "5". 