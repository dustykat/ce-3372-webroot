accept
# perceptions from peak file, experimented with LOTs, but leave as default. Allow code 6s.
