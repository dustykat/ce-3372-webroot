Completed 20FEB2019

Notes: Allowed urban peaks in calculation.